from flask import Flask
from controller.controllers import*

app=Flask(__name__)
app.register_blueprint(login_controller)
app.secret_key = "sua-chave-secreta"

if '__main__'==__name__:
    app.run(debug=True)