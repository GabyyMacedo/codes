from flask import Flask, render_template,Blueprint,request,redirect,url_for,session
from model.models import*

login_controller=Blueprint('login',__name__)

@login_controller.before_request
def request_info():
    print("Executa antes da requisição")

@login_controller.after_request
def response_info(response):
    print("Executa antes da resposta")
    return response

@login_controller.route('/')
def index():
    return render_template('index.html')

@login_controller.route('/login',methods=['POST','GET'])
def login():
    if request.method == 'POST':
        session.permanent = True
        session['usuario']=request.form['usuario']
        for i in usuarios:
            if i[0]==session['usuario'] and i[1]==request.form['senha']:
                return render_template('user.html')
        return render_template('index.html')
    else:
        return render_template('user.html')

@login_controller.route('/sair', methods=['POST'])
def sair():
    session.pop('usuario',None)
    return redirect(url_for('login.index'))