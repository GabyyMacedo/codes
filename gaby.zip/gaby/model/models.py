class Usuario:
    def __init__(self,nome,tipo):
        self.nome=nome
        self.tipo=tipo
usuarios=[]
usuarios.append(["Papaya","1234","Admin"])
usuarios.append(["Nubia","chinelo","Usuario"])
